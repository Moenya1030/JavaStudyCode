package lab3;

import java.util.Random;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random = new Random();
		int s = random.nextInt(10000);
		System.out.println(s);
	}

}
