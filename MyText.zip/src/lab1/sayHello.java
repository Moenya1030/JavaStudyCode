package lab1;

public class sayHello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("���Java");
		for (int i=0;i<=1000;i++)
			System.out.print(i);
	}

}
