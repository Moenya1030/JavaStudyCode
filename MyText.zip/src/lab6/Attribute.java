package lab6;

abstract public class Attribute {
		public void say()
		{
			
		}
		public String name;
		public int age;
		public String gender;

}
