package lab5;

public class Lab5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rec = new Rectangle();
		rec.setLength(10.5);
		rec.setWidth(9.5);
		System.out.println(rec.getLength());
		System.out.println(rec.getWidth());
		System.out.println(rec.getArea());
	}
}