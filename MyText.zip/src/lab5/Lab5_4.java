package lab5;

public class Lab5_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AlarmDoor ald = new AlarmDoor();
		ald.door();
		ald.alarming();
		ald.close();
		ald.close();
		ald.open();
		ald.open();
		ald.alarming();
		ald.close();
	}

}
