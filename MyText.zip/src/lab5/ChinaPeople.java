package lab5;

public class ChinaPeople extends people {
	public void chinakongfu()
	{
		System.out.println("chinakongfu");
	}
	public void speakHello()
	{
		System.out.println("i speak hello to u from china");
	}
}
