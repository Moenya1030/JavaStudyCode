package lab5;

public abstract class door {
	abstract void door();
	abstract void open();
	abstract void close();
}
